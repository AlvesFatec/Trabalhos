/**
 * Aula em Dia — Criação do formulário de pesquisa com professores.
 *
 * COMO USAR:
 * 1) Acesse https://script.google.com/ e crie um novo projeto.
 * 2) Cole este arquivo no editor, substituindo o conteúdo existente.
 * 3) Preencha os campos da constante DADOS.
 * 4) Execute criarFormularioAulaEmDia e autorize o acesso solicitado pelo Google.
 * 5) Consulte o Registro de execução para obter os links do formulário e da planilha.
 * 6) Revise tudo com o docente antes de publicar o formulário.
 *
 * IMPORTANTE: cada execução cria um NOVO formulário e uma NOVA planilha.
 */
function criarFormularioAulaEmDia() {
  const DADOS = {
    integrantes: 'PREENCHER NOMES DOS INTEGRANTES',
    emailContato: 'PREENCHER EMAIL DE CONTATO',
    responsavelAcademico: 'PREENCHER DOCENTE RESPONSAVEL',
    prazoArmazenamento: 'PREENCHER PRAZO DE GUARDA E DESCARTE'
  };

  const pendentes = Object.entries(DADOS)
    .filter(([chave, valor]) => !valor || valor.includes('PREENCHER'))
    .map(([chave]) => chave);
  if (pendentes.length > 0) {
    throw new Error('Preencha os dados do TCLE antes de executar: ' + pendentes.join(', '));
  }

  const formulario = FormApp.create('Aula em Dia - Pesquisa com Professores', false);
  formulario
    .setDescription('Pesquisa acadêmica sobre o planejamento docente e o possível uso de ferramentas digitais e inteligência artificial. Tempo estimado: 5 a 8 minutos. Leia o TCLE antes de responder.')
    .setIsQuiz(false)
    .setCollectEmail(false)
    .setLimitOneResponsePerUser(false)
    .setAllowResponseEdits(false)
    .setPublishingSummary(false)
    .setShowLinkToRespondAgain(false)
    .setShuffleQuestions(false)
    .setProgressBar(true)
    .setConfirmationMessage('Agradecemos sua atenção. Sua participação foi registrada conforme as opções selecionadas.');

  const termo = [
    'PESQUISA: Levantamento de necessidades de planejamento docente para o projeto Aula em Dia.',
    'RESPONSÁVEIS: ' + DADOS.integrantes + '.',
    'INSTITUIÇÃO: Fatec Itapetininga — Engenharia de Software III e Banco de Dados.',
    'DOCENTE RESPONSÁVEL: ' + DADOS.responsavelAcademico + '.',
    'CONTATO PARA DÚVIDAS: ' + DADOS.emailContato + '.',
    '',
    'OBJETIVO: compreender as dificuldades de professores ao preparar aulas e identificar recursos úteis para uma plataforma de planejamento com eventual apoio de inteligência artificial.',
    'PARTICIPAÇÃO: responder voluntariamente a 12 perguntas, em aproximadamente 5 a 8 minutos. A participação pode ser interrompida antes do envio, sem penalidades. Não haverá pagamento nem benefício individual garantido.',
    'RISCOS E CUIDADOS: desconforto pontual com perguntas sobre a rotina e risco residual de identificação indireta. Não informe nomes, e-mails, instituições, dados de estudantes ou outros identificadores nas respostas abertas.',
    'DADOS: não solicitaremos nome nem e-mail. As respostas serão acessadas apenas pela equipe e pelo docente responsável, quando necessário, e apresentadas de forma agregada ou devidamente anonimizada no relatório. O prazo e procedimento de guarda e descarte serão: ' + DADOS.prazoArmazenamento + '.',
    'RETIRADA: você pode desistir antes de enviar. Após o envio, por não haver identificação que permita localizar a resposta específica, poderá não ser possível retirá-la individualmente.',
    'Ao prosseguir, você declara que leu as informações e deseja participar livremente.'
  ].join('\n\n');

  formulario.addSectionHeaderItem()
    .setTitle('Termo de Consentimento Livre e Esclarecido (TCLE)')
    .setHelpText(termo);

  const consentimento = formulario.addMultipleChoiceItem()
    .setTitle('Você leu as informações acima e concorda voluntariamente em participar?')
    .setRequired(true);

  const paginaElegibilidade = formulario.addPageBreakItem()
    .setTitle('Critério de participação')
    .setHelpText('Esta pesquisa é direcionada somente a pessoas com 18 anos ou mais que atuam na docência.');

  const elegibilidade = formulario.addMultipleChoiceItem()
    .setTitle('Você tem 18 anos ou mais e atua como professor(a)?')
    .setRequired(true);

  const paginaPerguntas = formulario.addPageBreakItem()
    .setTitle('Questionário sobre planejamento docente')
    .setHelpText('Não inclua nomes ou informações que identifiquem você, estudantes ou instituições.');

  consentimento.setChoices([
    consentimento.createChoice('Sim, li e concordo voluntariamente', paginaElegibilidade),
    consentimento.createChoice('Não concordo', FormApp.PageNavigationType.SUBMIT)
  ]);
  elegibilidade.setChoices([
    elegibilidade.createChoice('Sim', paginaPerguntas),
    elegibilidade.createChoice('Não', FormApp.PageNavigationType.SUBMIT)
  ]);

  function selecaoUnica(pergunta, alternativas) {
    return formulario.addMultipleChoiceItem()
      .setTitle(pergunta)
      .setChoiceValues(alternativas)
      .setRequired(true);
  }
  function multiplaSelecao(pergunta, alternativas, instrucao) {
    const questao = formulario.addCheckboxItem()
      .setTitle(pergunta)
      .setChoiceValues(alternativas)
      .setRequired(true);
    if (instrucao) questao.setHelpText(instrucao);
    return questao;
  }

  selecaoUnica('Q1. Há quanto tempo você atua na docência?', [
    'Menos de 1 ano', '1 a 5 anos', '6 a 10 anos', 'Mais de 10 anos', 'Prefiro não informar'
  ]);
  selecaoUnica('Q2. Em qual etapa ou modalidade de ensino atua principalmente?', [
    'Educação infantil', 'Ensino fundamental', 'Ensino médio',
    'Ensino técnico ou superior', 'Educação de jovens e adultos', 'Outra', 'Prefiro não informar'
  ]);
  selecaoUnica('Q3. Com que frequência costuma preparar ou revisar planos de aula?', [
    'Diariamente', 'Semanalmente', 'Quinzenal ou mensalmente',
    'Conforme a necessidade', 'Outra'
  ]);
  multiplaSelecao('Q4. Quais meios utiliza atualmente para planejar aulas?', [
    'Papel/caderno', 'Editor de textos', 'Planilha', 'Plataforma da instituição',
    'Aplicativo especializado', 'Outro'
  ]);
  multiplaSelecao('Q5. Quais dificuldades encontra no planejamento?', [
    'Falta de tempo', 'Organização do histórico', 'Localização de materiais',
    'Adequação às turmas', 'Definição de avaliações',
    'Articulação com orientações curriculares', 'Outra', 'Não encontro dificuldades relevantes'
  ], 'Se marcar “Não encontro dificuldades relevantes”, não marque outras opções.');
  selecaoUnica('Q6. Quanto tempo costuma dedicar à preparação de um plano de aula?', [
    'Menos de 30 minutos', 'De 30 a 60 minutos', 'De 1 a 2 horas',
    'Mais de 2 horas', 'Varia muito'
  ]);

  const recursos = multiplaSelecao('Q7. Escolha até três recursos que seriam mais úteis em uma plataforma de planejamento.', [
    'Criar/editar planos', 'Reutilizar modelos', 'Consultar histórico',
    'Organizar por turma e data', 'Exportar planos', 'Sugestões por IA',
    'Referências curriculares', 'Compartilhar planos'
  ]);
  recursos.setValidation(FormApp.createCheckboxValidation()
    .setHelpText('Selecione no máximo três alternativas.')
    .requireSelectAtMost(3)
    .build());

  selecaoUnica('Q8. Você já utilizou ferramentas de inteligência artificial para apoiar atividades de planejamento?', [
    'Nunca', 'Algumas vezes', 'Frequentemente', 'Prefiro não informar'
  ]);
  multiplaSelecao('Q9. Em quais tarefas a IA poderia ser útil?', [
    'Sugerir objetivos', 'Sugerir atividades', 'Adaptar atividades',
    'Propor avaliações', 'Organizar um rascunho', 'Não desejo utilizar IA', 'Outra'
  ], 'Se marcar “Não desejo utilizar IA”, não marque outras opções.');
  multiplaSelecao('Q10. Quais seriam suas preocupações ao utilizar IA para planejar?', [
    'Informações incorretas', 'Inadequação pedagógica', 'Privacidade',
    'Dificuldade de uso', 'Dependência da ferramenta', 'Nenhuma dessas', 'Outra'
  ], 'Se marcar “Nenhuma dessas”, não marque outras opções.');
  selecaoUnica('Q11. Você consideraria experimentar um protótipo do Aula em Dia, caso fosse disponibilizado futuramente?', [
    'Sim', 'Talvez', 'Não'
  ]);
  formulario.addParagraphTextItem()
    .setTitle('Q12. Qual melhoria faria mais diferença no seu processo de planejamento de aulas?')
    .setHelpText('Opcional. Não informe nomes, instituições ou dados de estudantes.')
    .setRequired(false);

  const planilha = SpreadsheetApp.create('Aula em Dia - Respostas da Pesquisa');
  formulario.setDestination(FormApp.DestinationType.SPREADSHEET, planilha.getId());

  Logger.log('FORMULÁRIO PARA EDIÇÃO: ' + formulario.getEditUrl());
  Logger.log('PLANILHA VINCULADA: ' + planilha.getUrl());
  Logger.log('LINK PARA RESPONDER APÓS PUBLICAÇÃO: ' + formulario.getPublishedUrl());
  Logger.log('ATENÇÃO: formulário criado como rascunho. Revisar TCLE e publicar manualmente antes de convidar participantes.');
}
